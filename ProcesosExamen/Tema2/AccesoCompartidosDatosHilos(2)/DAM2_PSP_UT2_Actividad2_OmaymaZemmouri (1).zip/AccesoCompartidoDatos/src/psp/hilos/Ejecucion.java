package psp.hilos;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Ejecucion {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int numeroClientes =0;

        while(true){ /* hago este bucle para gestionar los errores de entrada*/
            try {
                System.out.println("¿Cuántos clientes vas a introducir?: ");
                numeroClientes = Integer.parseInt(s.nextLine());

                if (numeroClientes > 0)
                    break;
                else
                    System.out.println("Introduce un número correcto de clientes");
            } catch (NumberFormatException e){
                System.out.println("Introduce número válido");

            }
        }

        CuentaBancaria cueenta = new CuentaBancaria();

        List<Cliente> clientes = new ArrayList<>();
        /*creo los hilos y los inicio*/
        for (int i =1; i<=numeroClientes; i++) {
            Cliente cliente = new Cliente("Cliente " + i, cueenta);
            clientes.add(cliente);
            cliente.start();
        }
        /*espero a que todos los Clientes(hilos) terminen*/
        for (Cliente cliente : clientes){
            try{
                cliente.join();
            } catch (InterruptedException e){
                System.out.println("Error de :" + cliente.getName());
            }
        }

        double totalTransaccion =0;
        /*para sumar todas las transacciones*/
        for (Cliente cliente : clientes){
            totalTransaccion += cliente.getTotalTransacciones();
        }
        double saldoFinal = cueenta.getSaldo();
        double saaldo = CuentaBancaria.saldoInicial + totalTransaccion;
        double desajuste = saldoFinal - saaldo;

        System.out.println("Saldo inicial :" +  CuentaBancaria.saldoInicial);
        System.out.println("Saldo final :" + saldoFinal);
        System.out.println("Total transacciones :" + totalTransaccion);
        System.out.println("Desajuste :" + desajuste);
    }
}
