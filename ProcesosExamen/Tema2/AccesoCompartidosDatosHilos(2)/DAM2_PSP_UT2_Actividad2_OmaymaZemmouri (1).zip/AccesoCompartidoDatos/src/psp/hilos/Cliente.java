package psp.hilos;

import java.util.Random;

public class Cliente extends Thread {
    private double totalTransacciones=0;
    private CuentaBancaria cueenta;

    private Random r = new Random();
    /*nuestras constantes para fijar los máximos que nos pedía el encunciado de la tarea*/
    private static final int numMaxOperacione=8;
    private static final double maxDinero = 1000;
    private static final int maxPausa = 700;

    /* nuestro constructo*/
    public Cliente (String nombre, CuentaBancaria cueenta){
        super(nombre);
        this.cueenta = cueenta;

    }
    /*para obtener el total de transacciones del cliente*/
    public double getTotalTransacciones() {
        return totalTransacciones;
    }

    @Override

    public void run(){
        /*sumo 1 para que asegurarme de que haya al menos una operacion*/
        int numOperaciones = r.nextInt(numMaxOperacione);

        /*para generar la cantidad de dinero y redondear*/
        for (int i=0; i<numOperaciones; i++){
            double dinero = Math.round(r.nextDouble() * maxDinero);
            boolean retirar = r.nextBoolean();

            if (retirar) {
                /*llama al método synchronized y recibe el true si ha tenido éxito(de la clase CuentaBancaria)*/
                boolean retiradaHecha = cueenta.retirarDinero(getName(), dinero);
                if (retiradaHecha) {
                    totalTransacciones -= dinero;
                }
            }
            else{
                cueenta.depositarDinero(getName(), dinero);
                totalTransacciones += dinero;
                }
            try {
                Thread.sleep(r.nextInt(maxPausa) + 100);
            } catch (InterruptedException e){
                System.out.println(getName() + " ha sido interrumpido" );
            }
        }
    }

}

