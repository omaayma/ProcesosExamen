package psp.hilos;

public class CuentaBancaria {

    public static final double saldoInicial=20000; /*constante paa fijar el saldo inicial*/
    private double saldo;


    public CuentaBancaria(){ /*nuestro constructor*/
        saldo=saldoInicial;//para inicializar el saldo junto con la constante
    }

    public double getSaldo() {

        return saldo; /*para devolver el saldo actual*/
    }

    /*método para retirar dinero y usamos synchronized para evitar condiciones de carrera*/
    synchronized public boolean retirarDinero(String nombre, double dinero){
        if (dinero<=saldo) { /*uso boolean para indicar al cliente si la retirada ha tenido éxito*/
            saldo -= dinero;
            System.out.println(nombre + " ha retirado " + dinero + "€");
            return true;
        }else{ /* en el caso de que no se pueda retirar*/
            System.out.println(nombre + " intenta retirar dinero pero no hay saldo suficiente en la cuenta" );
            return false;
        }
    }
    synchronized  public void depositarDinero(String nombre, double dinero){
        saldo += dinero; /*para sumar el dinero al saldo (depositar dinero en la cuenta)*/
        System.out.println(nombre + " ha depositado " + dinero + "€ en la cuenta"  );
    }
}
