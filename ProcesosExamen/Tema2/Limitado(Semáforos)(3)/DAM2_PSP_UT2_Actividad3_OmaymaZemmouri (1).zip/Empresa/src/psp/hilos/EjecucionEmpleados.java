package psp.hilos;

import java.util.Scanner;
import java.util.concurrent.Semaphore;

public class EjecucionEmpleados {
    public static void main(String [] args){
        int numEmpleados=0;
        int recursos =0;
        Scanner scanner = new Scanner(System.in);

        try{ /*Aquí pido el número de recursos*/
            System.out.print("Introduce el número de puestos/ordenadores disponibles: ");
            recursos=scanner.nextInt();
            if (recursos <= 0){
                System.out.println("Por favor, introduce un número mayor que 0");
                return;
            }
            /*Ahora pediré al usuario el número de empleados*/
            System.out.print("Introduce el número de empleados(No olvide que tiene que ser mayor que " + recursos + "):" );
            numEmpleados = scanner.nextInt();
            if (numEmpleados <= recursos){
                System.out.println("Inválido. Recuerde que tiene que haber más empleados que los puestos/ordenadores");
                return;
            }

        } catch(Exception e){
            System.out.println("Error. Introduce un número entero");
            return;
        }
        /*Ahora creo los semáforos para evitar condiciones de carrera/interbloqueos*/
        Semaphore puestos = new Semaphore(recursos);
        Semaphore ordenadores = new Semaphore(recursos);

        /*Ahora creo un array de hilos(empleados)*/
        Empleado[] empleados = new Empleado[numEmpleados];

        for (int i =0; i<numEmpleados; i++){
            empleados[i] = new Empleado(i+1, puestos, ordenadores);
            empleados[i].start();
        }

    }

}

