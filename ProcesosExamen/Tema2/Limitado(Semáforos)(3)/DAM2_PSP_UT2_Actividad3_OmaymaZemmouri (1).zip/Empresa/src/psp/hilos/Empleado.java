package psp.hilos;

import java.util.Random;
import java.util.concurrent.Semaphore;

public class Empleado extends Thread {

    /*Inicializamos las constantes*/
    private static final Random random = new Random();
    private static final int tiempoTrabajo = 1000;
    private static final int tiempoDescanso = 1000;

    private int idEmpleado;
    private Semaphore ordenadores;
    private Semaphore puestos;

    public Empleado(int id, Semaphore ordenadores, Semaphore puestos) {
        this.idEmpleado = id;
        this.puestos = puestos;
        this.ordenadores = ordenadores;

    }

    @Override
    public void run() {
        try {
            /*Para coger puesto u ordenador se decide aleatoriamente*/
            while (true) {
                if (random.nextBoolean()) {
                    cogerOrdenadorPrimero();
                } else {
                    cogerPuestoPrimero();
                }
                /*Trabaja un tiempo aleatorio*/
                System.out.println("El empleado " + idEmpleado + "está trabajando");
                Thread.sleep(random.nextInt(tiempoTrabajo) + 1000);

                /*Después, se liberan los recursos*/
                puestos.release();
                ordenadores.release();
                System.out.println("El empleado " + idEmpleado + "ya no está trabajando(deja los recursos)");
                /*Ahora toca el descanso*/
                Thread.sleep(random.nextInt(tiempoDescanso) + 1000);
            }
        } catch (InterruptedException e) {
            System.out.println("El empleado " + idEmpleado + "ya ha terminado su jornada");
        }
    }
    /*Implementados los métodos principales*/

    private void cogerOrdenadorPrimero() throws InterruptedException{
        ordenadores.acquire();
        System.out.println("El empleado " + idEmpleado + "ha cogido un ordenador");
        Thread.sleep(100);
        puestos.acquire();
        System.out.println("El empleado " + idEmpleado + "ha cogido un puesto");

    }
    private void cogerPuestoPrimero() throws InterruptedException{
        puestos.acquire();
        System.out.println("El empleado " + idEmpleado + "ha cogido un puesto");
        Thread.sleep(100);
        ordenadores.acquire();
        System.out.println("El empleado " + idEmpleado + "ha cogido un ordenador");

    }
}
