package psp.hilos;

import java.util.Scanner;

public class Ejecucion {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("¿Cuántos triángulos quieres calcular? ");
        int numTriangulos = sc.nextInt();

        System.out.print("Quiere asignar prioridad al cálculo de los triángulos? (S o N) ");
        char prio = sc.next().toLowerCase().charAt(0); //para que sea en mínúscula tal y como lo tiene el profe en el ejemplo
        boolean asignarPrioridad = (prio == 's'); //para que se asigne prioridad en caso de que el usuario lo pida

        Triangulo[] triangulos = new Triangulo[numTriangulos];
        Thread[] hilos = new Thread[numTriangulos];//para guardar los hilos

        for (int i = 0; i < numTriangulos; i++) { //para pedir los datos del triángulo
            System.out.println();
            System.out.println("Triángulo " + (i + 1) + ": ");

            System.out.print("Introduce la base: ");
            double base = sc.nextDouble();

            System.out.print("Introduce la altura: ");
            double altura = sc.nextDouble();

            int prioridad = 3;
            //en el caso de que se pida asignar prioridad:
            if (asignarPrioridad) {
                System.out.print("Introduce la prioridad de 1 a 10");
                prioridad = sc.nextInt();
            }
            //Creamos el objeto Triángulo y los hilos asociados
            Triangulo t = new Triangulo(i + 1, base, altura, prioridad);
            triangulos[i]=t;

            Thread hilo = new Thread(t);
            hilo.setPriority(prioridad);
            hilos[i] = hilo;//para guradr el hilo en el array
        }

        System.out.println();

        //ahora esperamos a que los hilos terminen
        for (Thread hilo : hilos){
            hilo.start();
        }

        for (Thread thread : hilos){
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

    }
}
