package psp.hilos;

public class Triangulo implements Runnable {
    /*LO primero que hacemos sería los atributos de la clase Triángulo*/
    private double base;
    private double altura;
    private int id;
    private int prioridad;
    private double area;


    //Ahora vamos con el constructor
    public Triangulo(int id,double base, double altura, int prioridad){
        this.base = base;
        this.altura = altura;
        this.id = id;
        this.prioridad = prioridad;
    }

    @Override
    public void run() {
        /*Calculamos área con nuestro método*/
        this.area = calcularArea();
        System.out.println("Triángulo " + id + ": base = " + base + ", altura = " + altura +
                ", prioridad = " + prioridad + ", área = " + area);

    }
    public double getArea(){
        return area;
    }
    public int getId(){
        return id;
    }

    private double calcularArea(){
        double parteEntera = Math.floor(altura);
        double parteDecimal = altura - parteEntera;

        double suma =0;//para el acumulador de suma

        for (int i =0; i<parteEntera; i++){ //Para sumar la base las veces que indica la parte entera de la altura
            suma += base;
        }
        suma += base * parteDecimal; //para la parte decima
        return suma / 2;

    }

}
