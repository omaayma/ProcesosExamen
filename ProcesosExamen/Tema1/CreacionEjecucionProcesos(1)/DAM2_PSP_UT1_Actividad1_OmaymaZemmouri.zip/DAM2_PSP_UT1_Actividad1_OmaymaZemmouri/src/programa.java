import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.Scanner;

public class programa{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); /*Usamos el scanner para leer la entrada del usuario*/
        String sistema = System.getProperty("os.name").toLowerCase();/*Como ha comentado el profesor en clase, esto nos va a devolver el nombre del sistema operativo*/
        final boolean esWin;
        if (sistema.contains("win")) {
            esWin = true; /*Con esto podremos saber si se trata del sistema operativo Windows*/
        }else{
            esWin= false;
        }
        System.out.println("El sistema es:" + (esWin ? "Windows" : "Linux"));



        /*Ahora vamos a hacer un menú de las opciones que quiera elegir el usuario utilizando un bucle*/

        while (true) {
            System.out.println("\n Elige una opción:");
            System.out.println("1. Ejecutar un ping");
            System.out.println("2. Listar ficheros y guardarlos en un archivo");
            System.out.println("3.Leer los procesos del sistema y cerrar por PID");
            System.out.println("4. Ejecutar navegador mediante la URL que va a introducir");
            System.out.println("5. Salir");
            System.out.println("La opción esocogida es:");

            String opcion = scanner.nextLine();/*Nos permite leer la opción que va a escoger el usuario*/
            if (opcion.equals("5")) {  /*En este caso para salir del bucle y finalizar el programa*/
                System.out.println("Usted va a salir del programa");
                break;
            }

            try {
                if (opcion.equals("1")) {  /*La primera opción era ejecutar un ping */
                    System.out.println("Escriba un host o IP:");
                    final String host = scanner.nextLine();

                    /*Vamos a crear un hilo para ejecutar el ping*/
                    Thread hilo = new Thread(new Runnable() {
                        public void run() {
                            try {
                                String[] comando;
                                if (esWin) {  /*A continuación, ponemos el comando ping en Windows*/
                                    comando = new String[]{"ping", "-n", "4", host}; /*La verdad es que tuve que buscar y aprender cómo crear el hilo, ya que no sabía como hacerlo. El -n indica el número de paquetes*/
                                } else {
                                    comando = new String[]{"ping", "-c", "4", host}; /*En este caso es en Linux. El -c indica el número de paquetes*/
                                }
                                ejecutarYMostrar(comando);
                            } catch (Exception e) {
                                System.out.println("Ha habido un error:" + e.getMessage());
                            }
                        }
                    });
                    hilo.start(); /*Para lanzar y ejecutar el hijo*/
                }

                /*Ahora vamos con los archivos que se quiere listar, además de guardarlos en un archivo*/
                else if (opcion.equals("2")) { /*En este apartado vamos a pedir al usuario que introduzca el directorio que quiere listar*/
                    System.out.println("Directorio que quiere listar:");
                    String directorio = scanner.nextLine();


                    /*Vamos a pedir el nombre del archivo donde se quiere guardar la losta*/
                    System.out.println("Introduce el nombre del archvio donde quiere transferir la lista:");
                    String archvioIndicado = scanner.nextLine();


                    /*Según el sistema operativo, crearemos un comando u otro*/
                    String[] comando;
                    if (esWin) { /*En el caso de Windows*/
                        comando = new String[]{"cmd", "/c", "dir", directorio};
                    } else { /*En el caso de Linux*/
                        comando = new String[]{"ls", "-la", directorio};
                    }
                    try{
                        String ejecución = ejecutarYCapturar(comando); /*Para que se ejecute el comando y se capture el resultado final*/

                        /*Vamos a guardar el resultado en el archivo elegido por el usuario*/

                        FileWriter fw = new FileWriter(archvioIndicado);
                        fw.write(ejecución);
                        fw.close();
                        System.out.println("Se ha guradado en:" + archvioIndicado);

                    }catch (Exception e){
                        System.out.println("Error:" + e.getMessage());
                    }


                    /*En este apartado mostraremos los procesos y los cerraremos por PID*/
                } else if (opcion.equals("3")) {
                    /*De nuevo, usaremos los comandos necesarios según el sistema operativo*/
                    String[] comando;
                    if (esWin) { /*En el caso de Windows*/
                        comando = new String[]{"cmd", "/c", "tasklist"};
                    } else { /*En el caso de Linux*/
                        comando = new String[]{"ps", "-e"};
                    }
                    /*Vamos a mostrar los procesos*/
                    System.out.println("Procesos del sistema:");
                    ejecutarYMostrar(comando);


                    /*Vamos a pedir al usuario si quiere cerrar un proceso*/
                    System.out.println("Introduce el PID que quiere cerrar:");
                    String pid = scanner.nextLine();
                    /*Primero vamos a comprobar que el usuario al menos ha introducido algo(que no esté vacío)*/
                    if (!pid.trim().isEmpty()) {
                        String[] comando1;
                        if (esWin) { /*Si el sistema es Windows usamos los siguintes comandos*/
                            comando1 = new String[]{"cmd", "/c", "taskkill", "/PID", pid, "/F"};
                        } else { /*En el caso de Linux, investigando, supe que -9 envía la señal para forzar la terminación*/
                            comando1 = new String[]{"kill", "-9", pid};
                        }
                        ejecutarYMostrar(comando1);/*Ejecutamos el comando correspondiente*/
                        System.out.println("El proceso con PID:" + pid + " ha sido cerrado");
                    }

                    /*Toca la opción 4,que es abrir el navegador con la url dada por el usuario*/
                } else if (opcion.equals("4")) {
                    System.out.println("Por favor, introduzca una URL:");
                    String url = scanner.nextLine();

                    if (esWin) { /*Como hemos aprendido en clase Runtime, ahora la usamos para abrir el navegador*/
                        String[] comando = new String[]{"cmd", "/c", "start", url};
                        Runtime.getRuntime().exec(comando);
                    } else { /*En el caso de Linux, usaremos ProcessBuilder, e investigando aprendí que se hace con xdg-open*/
                        String[] comando = new String[]{"xdg-open", url};
                        new ProcessBuilder(comando).start();
                    }
                } else {
                    System.out.println("Introduce una opción válida");
                }
            } catch(Exception exception){
                System.out.println("Ha habido un error:" + exception.getMessage());
            }
        }
        scanner.close();
    }
    /*Finalmente vamos a lanzar los procesos*/
    private static void ejecutarYMostrar (String[]comando) throws Exception {
        ProcessBuilder pb = new ProcessBuilder(comando);
        pb.redirectErrorStream(true);
        Process p = pb.start();
                /*Vamos a leer la salida del proceso con BufferedReader*/
        BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
        String linea;
        /*Con el siguiente bucle mostramos linea por linea*/
        while ((linea = br.readLine()) != null) {
            System.out.println(linea);
        }
        p.waitFor();/*Para esperar a que se termine el proeso*/
        br.close();
    }
    private static String ejecutarYCapturar (String[]comando) throws Exception {
        ProcessBuilder pb = new ProcessBuilder(comando);
        pb.redirectErrorStream(true);
        Process p = pb.start();

        BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
        StringBuilder sb = new StringBuilder();
        String linea;
        while ((linea = br.readLine()) != null) {
            sb.append(linea).append(System.lineSeparator());
        }
        p.waitFor();
        br.close();
        /*Para que devuelva todo como  texto*/
        return sb.toString();
    }
}






