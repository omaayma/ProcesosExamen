import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Aplicacion {

    public static void main(String[] args) throws IOException, InterruptedException {

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in)); //Para crear la entrada(teclado), y uso BufferedReader para leer líneas completas de texto
        String classpath= "C:\\Users\\zemmo\\IdeaProjects\\ComunicacionEntreProcesos\\out\\production\\ComunicacionEntreProcesos";

        //Vamos a usar un bucle para se repita hasta que el usuario escriba fin
        while (true) {
            System.out.print("> ");//He visto que en el ejemplo del profe usa este signo, supongo para indicar al usuario que escriba
            String linea = br.readLine();//Para leer lo que introduce el usuario

            if (linea.equalsIgnoreCase("fin")) {
                break; //para salir del bucle si el usuario escribe fin

            }
            //Vamos a concatenar los números generados por los hijos
            StringBuilder finalNumeros = new StringBuilder();

            //Ahora vamos a recorrer cada carácter de la línea que escribe el usuario y por cada carácter creamos un proceso hijo
            for (int i = 0; i < linea.length(); i++) {
                ProcessBuilder pb = new ProcessBuilder("java", "-cp",classpath,"NumeroAleatorio");
                //Usé ProcessBuilder para ejecutar la clase NumeroAleatorio
                //Ahora vamos a iniciar el proceso hijo y guardarlo
                Process p = pb.start();

                BufferedReader output = new BufferedReader(new InputStreamReader(p.getInputStream()));//Para que podamos leer lo que imprime el proceso hijo
                String num = output.readLine();//para leer el número aleatorio generado por el hijo
                finalNumeros.append(num);//Para añadir el número al concatenación final

                p.waitFor();
            }
            System.out.println(finalNumeros.toString());
        }
    }
}
