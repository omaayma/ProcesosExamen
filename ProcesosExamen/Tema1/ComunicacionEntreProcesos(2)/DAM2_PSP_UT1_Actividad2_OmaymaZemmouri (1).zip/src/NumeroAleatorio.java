import java.util.Random;

public class NumeroAleatorio {
    public static void main(String[] args) {

        Random r = new Random(); //Creo un objeto de la clase Random para generar números aleatorios
        int num = r.nextInt(10); //Ya que queremos un número aleatorio entre 0 y 9
        System.out.println(num);

    }
}
