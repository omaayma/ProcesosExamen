package psp.procesos.a13;

import javax.swing.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class BuscadorTexto extends JFrame {

    public BuscadorTexto() {
        this.setResizable(false);
        // ya que creo que el proceso hijo no es el que debe cerrar this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public void buscarTexto(String idFichero, String opcionBucar) {
        String nomFich = "texto" + idFichero + ".txt";
        int contador = 0;

        try {
            BufferedReader br = new BufferedReader(new FileReader(nomFich));//Para la lectura del fichero
            String linea;

            //vAMOS a leer ell archivo linea por linea
            while ((linea = br.readLine()) != null) {
                if (linea.equals(opcionBucar)) {
                    contador++;
                }
            }
            br.close();
            JOptionPane.showMessageDialog(null, "Valores encontrados: " + contador + "\nOpción -> " + opcionBucar + "\nFichero -> " + idFichero);
        } catch (IOException e) {
            e.printStackTrace();

        }
    }

    public static void main(String[] args) {
        if (args.length != 2){ //ya que el proceso hijo recibe los argumentos del padre
            System.out.println("Error");
            return;
        }
        BuscadorTexto bus = new BuscadorTexto();
        bus.buscarTexto(args[1], args[0]);

    }

}