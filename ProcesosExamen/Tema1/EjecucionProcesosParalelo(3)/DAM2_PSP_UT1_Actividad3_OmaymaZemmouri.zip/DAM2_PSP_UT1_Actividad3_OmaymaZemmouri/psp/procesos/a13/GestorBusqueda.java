package psp.procesos.a13;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class GestorBusqueda extends JFrame implements ActionListener{
    private JTextField texto;
    private JTextField fichero;
    private JButton botonBuscar;
    private JButton botonCancelar;
    private JButton botonSalir;

    //Vamos a poner las opciones necearias para la validación
    private static final List<String> opcValida = Arrays.asList("CASA", "PERRO", "COCHE");
    private static final List<String> fichValido = Arrays.asList("1", "2", "3", "4", "5");

    //Ahora procedemos con los procesos
    private List<Process> procesos = new ArrayList<>();

    public GestorBusqueda() { //este es el constructor que va a crear la ventana
        super("GESTOR DE BÚSQUEDA");

        setSize(450, 350);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        setLayout(new GridLayout(6, 1, 0, 5));//Para el ajuste del layout
        setLocationRelativeTo(null);//ya que quiero que mi ventana esté en el centro de la pantalla

        JLabel tit = new JLabel("BUSCAR TEXTO EN FICHERO", SwingConstants.CENTER);//YA QUE QUIERO QUE EL TEXTO ESTÉ EN EL CENTRO
        add(tit);
        /*
        //Ahora vamos con las opciones de búsqueda
        add(new JLabel("Opciones de búsqueda: CASA PERRO COCHE", SwingConstants.CENTER));
        //Los ficheros de búsqueda
        add(new JLabel("Ficheros de búsqueda: 1 a 5", SwingConstants.CENTER));
        */
        // Sustituye las dos líneas anteriores por esta única línea ya que antes no salía alineado:
        JLabel texto2 = new JLabel("<html>" + "Opciones de búsqueda: CASA PERRO COCHE<br>" +
                "Ficheros de búsqueda: 1 a 5" + "</html>", SwingConstants.CENTER);
        add(texto2);


        //Vamos a usar un panel para la opcion
        JPanel panelOpc = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panelOpc.add(new JLabel("Introduzca opción:           "));
        texto = new JTextField(10);
        panelOpc.add(texto);
        add(panelOpc);

        //Panel para los ficheros
        JPanel pFichero = new JPanel(new FlowLayout(FlowLayout.CENTER));
        pFichero.add(new JLabel("Introduzca fichero:           "));
        fichero = new JTextField(10);
        pFichero.add(fichero);
        add(pFichero);

        //Panel para nuestros botones
        JPanel pBot = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0));
        botonBuscar = new JButton("Buscar");
        botonCancelar = new JButton("Cancelar");
        botonSalir = new JButton("Salir");

        pBot.add(botonBuscar);
        pBot.add(botonCancelar);
        //pBot.add(botonSalir);
        add(pBot);

        //Ahora voy a usar el ActionListener de buscar
        botonBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String palabra = texto.getText().trim();//para obtener lo que escribió el usuario
                String id = fichero.getText().trim();


                //Ahora quiero comprobar si lo que se escribe es una de las opciones que tenemos
                if (!opcValida.contains(palabra)) {
                    JOptionPane.showMessageDialog(GestorBusqueda.this, "Opción incorrecta", "Error:", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                if (!fichValido.contains(id)) {
                    JOptionPane.showMessageDialog(GestorBusqueda.this, "Fichero incorrecto", "Error:", JOptionPane.ERROR_MESSAGE);
                    return; //para parar la ejecución en caso de error
                }
                lanzarBusqueda(palabra, id);

            }
        });
        //Ahora lo hacemos en el caso de cancelar
        botonCancelar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cancelarProcesos(); //Para acabar con procesos hijos

            }
        });
        //ActionListener de salir
        botonSalir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cancelarProcesos();
                System.exit(0);
            }
        });
        //Para garantizar que nuestros procesos se cancelen
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                cancelarProcesos();
                System.exit(0);
            }
        });

        setVisible(true);
    }

    private void lanzarBusqueda(String palabra, String fich) {
        try {
            ProcessBuilder pb = new ProcessBuilder(
                    "java",
                    "-cp", System.getProperty("java.class.path"),
                    "psp.procesos.a13.BuscadorTexto",
                    palabra, fich);

            pb.inheritIO();//para que herede(consola)
            Process p = pb.start();
            procesos.add(p);

        } catch (Exception e) {
            e.printStackTrace();

        }
    }
    private void cancelarProcesos() {
        //Para recorrer la lista de los procesos
        for (Process pr : procesos) {
            pr.destroy();
        }
        procesos.clear();
        texto.setText("");//para que se borre lo que teníamos anteriormente
        fichero.setText("");
        JOptionPane.showMessageDialog(this,
                "Se han cancelado todas las búsquedas",
                "Procesos cancelados", JOptionPane.ERROR_MESSAGE);


    }

    public static void main(String[] args) {
        new GestorBusqueda();

    }

    @Override
    public void actionPerformed(ActionEvent actionEvent) {

    }
}